# fsh-tutorial
The source code for the tutorial examples included as a zip file in the FSH documentation.
For more information, see the online [FSH Tutorial](http://build.fhir.org/ig/HL7/fhir-shorthand/tutorial.html).

When updates are to be published (incorporated into the FSH Documentation), download the zip from the master branch, and put it into the /input/includes/pagecontent directory of the tutorial. The repo containing the FSH Documentation is found [here](https://github.com/HL7/fhir-shorthand).
